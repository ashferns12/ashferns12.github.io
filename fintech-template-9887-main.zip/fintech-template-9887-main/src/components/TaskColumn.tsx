
import React, { useState } from 'react';
import TaskCard, { Task } from './TaskCard';

export interface Column {
  id: string;
  title: string;
  color: string;
  tasks: Task[];
}

interface TaskColumnProps {
  column: Column;
  onDrop: (e: React.DragEvent, columnId: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: (e: React.DragEvent) => void;
  onTaskDragStart: (e: React.DragEvent, task: Task) => void;
  onTaskDragEnd: () => void;
  onStatusChange: (taskId: string, newStatus: string) => void;
}

const TaskColumn: React.FC<TaskColumnProps> = ({
  column,
  onDrop,
  onDragOver,
  onDragLeave,
  onTaskDragStart,
  onTaskDragEnd,
  onStatusChange
}) => {
  const [isOver, setIsOver] = useState(false);
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsOver(true);
    onDragOver(e);
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    setIsOver(false);
    onDragLeave(e);
  };
  
  const handleDrop = (e: React.DragEvent) => {
    setIsOver(false);
    onDrop(e, column.id);
  };

  // Get status indicator color based on column
  const getStatusColor = () => {
    switch (column.id) {
      case 'todo':
        return 'bg-slate-400';
      case 'in-progress':
        return 'bg-blue-400';
      case 'in-review':
        return 'bg-amber-400';
      case 'completed':
        return 'bg-emerald-400';
      default:
        return 'bg-muted';
    }
  };

  return (
    <div 
      className={`premium-column flex flex-col w-80 min-w-80 rounded-2xl transition-all duration-300 ${
        isOver ? 'column-highlight border-primary/40' : ''
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="p-4 border-b border-border/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <span className={`h-3 w-3 rounded-full ${getStatusColor()} shadow-lg`}></span>
            <span className={`absolute inset-0 h-3 w-3 rounded-full ${getStatusColor()} animate-ping opacity-30`}></span>
          </div>
          <h4 className="font-semibold text-sm text-foreground tracking-tight">{column.title}</h4>
          <span className="text-xs bg-muted/30 backdrop-blur-sm px-2.5 py-1 rounded-full text-muted-foreground border border-border/30 font-medium">
            {column.tasks.length}
          </span>
        </div>
        <button className="text-muted-foreground/60 hover:text-foreground transition-colors p-1 rounded-md hover:bg-muted/20">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 12V12.01M8 12V12.01M16 12V12.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
      
      <div className="p-3 flex-1 space-y-3 overflow-auto min-h-0 max-h-[calc(100vh-12rem)]">
        {column.tasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            onDragStart={onTaskDragStart}
            onDragEnd={onTaskDragEnd}
            onStatusChange={onStatusChange}
          />
        ))}
        {column.tasks.length === 0 && (
          <div className="flex flex-col items-center justify-center py-8 text-muted-foreground/50">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mb-3 opacity-40">
              <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <p className="text-xs font-medium">No tasks yet</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskColumn;
