
import React, { useState, useRef } from 'react';

export interface Task {
  id: string;
  title: string;
  description: string;
  tag: {
    color: string;
    label: string;
  };
  dueDate: string;
  assignees: number;
  progress: {
    completed: number;
    total: number;
  };
}

interface TaskCardProps {
  task: Task;
  onDragStart: (e: React.DragEvent, task: Task) => void;
  onDragEnd: () => void;
  onStatusChange: (taskId: string, newStatus: string) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onDragStart, onDragEnd, onStatusChange }) => {
  const [isDragging, setIsDragging] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleDragStart = (e: React.DragEvent) => {
    setIsDragging(true);
    
    // Add ghost image effect
    if (cardRef.current) {
      const rect = cardRef.current.getBoundingClientRect();
      const ghostImage = cardRef.current.cloneNode(true) as HTMLDivElement;
      ghostImage.style.position = 'absolute';
      ghostImage.style.top = '-1000px';
      ghostImage.style.opacity = '0.8';
      document.body.appendChild(ghostImage);
      e.dataTransfer.setDragImage(ghostImage, rect.width / 2, rect.height / 2);
      
      // Clean up the ghost element after drag
      setTimeout(() => {
        document.body.removeChild(ghostImage);
      }, 0);
    }
    
    onDragStart(e, task);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    onDragEnd();
  };
  
  // Generate premium tag styling based on color
  const getTagClass = (color: string) => {
    const baseClass = 'premium-tag text-xs font-semibold px-3 py-1.5 rounded-full border relative z-10';
    
    switch (color) {
      case 'purple':
        return `${baseClass} text-purple-300 border-purple-500/30 bg-purple-500/10`;
      case 'blue':
        return `${baseClass} text-blue-300 border-blue-500/30 bg-blue-500/10`;
      case 'accent':
        return `${baseClass} text-emerald-300 border-emerald-500/30 bg-emerald-500/10`;
      default:
        return `${baseClass} text-muted-foreground border-border/50 bg-muted/20`;
    }
  };

  return (
    <div
      ref={cardRef}
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      className={`task-card p-5 h-48 flex flex-col group cursor-grab active:cursor-grabbing ${isDragging ? 'dragging' : ''}`}
    >
      {/* Header with tag and due date */}
      <div className="flex justify-between items-start mb-4 flex-shrink-0">
        <span className={getTagClass(task.tag.color)}>
          {task.tag.label}
        </span>
        <span className="text-muted-foreground/70 text-xs font-medium bg-muted/20 px-2 py-1 rounded-md">
          {task.dueDate}
        </span>
      </div>
      
      {/* Main content area */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Title and description */}
        <div className="flex-1 mb-4">
          <h5 className="font-semibold mb-2 text-foreground text-sm leading-tight line-clamp-2 group-hover:text-primary transition-colors">
            {task.title}
          </h5>
          <p className="text-xs text-muted-foreground/80 line-clamp-3 leading-relaxed">
            {task.description}
          </p>
        </div>
        
        {/* Footer with assignees and progress */}
        <div className="flex justify-between items-center flex-shrink-0 mt-auto">
          <div className="flex -space-x-2">
            {[...Array(task.assignees)].map((_, i) => (
              <div 
                key={i}
                className={`premium-avatar h-7 w-7 rounded-full border-2 border-background transition-transform hover:scale-110 hover:z-10`}
                style={{
                  background: `linear-gradient(135deg, hsl(var(--muted)) ${100 - i * 20}%, hsl(var(--muted-foreground)) 100%)`
                }}
              ></div>
            ))}
          </div>
          
          {task.progress.completed === task.progress.total ? (
            <span className="premium-progress-complete flex items-center gap-1.5 text-xs font-semibold">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5 12L10 17L19 8" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              {task.progress.completed}/{task.progress.total}
            </span>
          ) : (
            <span className="premium-progress-incomplete flex items-center gap-1.5 text-xs font-semibold">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none"/>
                <circle cx="12" cy="12" r="3" fill="currentColor"/>
              </svg>
              {task.progress.completed}/{task.progress.total}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default TaskCard;
