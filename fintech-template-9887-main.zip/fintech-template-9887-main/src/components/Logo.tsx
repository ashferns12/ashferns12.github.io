
import React from 'react';

const Logo = () => {
  return (
    <div className="flex items-center gap-3">
      <div className="h-6 w-6 bg-foreground rounded-sm"></div>
      <span className="text-xl font-medium text-foreground">opulent.ai</span>
    </div>
  );
};

export default Logo;
